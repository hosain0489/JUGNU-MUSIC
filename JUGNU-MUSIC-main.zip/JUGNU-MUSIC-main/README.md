# **IMPORTANT**

**Make Sure You Give Credit.. Thank You**

[Join my Support Server](https://discord.gg/tVWrU5PWZV)

## HOW TO SELFHOSt

- download `nodejs` v12 or higher, and `ffmpeg`

- install all dependeces with `npm install`

- start your Bot with `node index.js`

Enjoy ;)

[REPLIT](https://replit.com/@kabirjaipal/Jugnu-or-Best-Music-Bot-on-Replit?v=1)

*Yes It Works on REPLIT*

# **Hosting**

Need a hosting to host a minecraft server or discord bot server 24/7 ? I recommend using https://futurehosting.org/ . They provide 24/7 server hosting with best performance at affordable price and discounts . They also have 24/7 support on their discord and site .

Site : https://futurehosting.org/

Discord : https://discord.gg/DNme6pzFQB

Order discord bot server : https://billing.futurehosting.org/index.php?rp=/store/discord-bot-voice-hosting

**Discord Server:**
[https://discord.gg/tVWrU5PWZV](https://discord.gg/tVWrU5PWZV)

## Special 
This is Bot Have 24/7 Free Service
For Info CheckOut My Video
https://youtu.be/shf7FJGpbCc

## Credits

[@tomato](https://github.com/Tomato6966/) For the Reacting system to messages, great Idea i adopted that [@Tomato6966/Musicium](https://github.com/Tomato6966/Musicium)

Thanks For Tomato6966
Check Out Tomato6966 Gtihub Repo
